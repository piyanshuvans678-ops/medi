/* MediTime - Smart Medicine Reminder (educational prototype, NOT a medical device) */
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <RTClib.h>

// ---------- Pins ----------
const int BUZZER = 8, GREEN_LED = 9, RED_LED = 10;
const int BTN_PINS[3] = {2, 3, 4};      // 0 = Confirm, 1 = Next, 2 = Mode/Test

// ---------- Settings you can change ----------
int remH[3] = {8, 14, 20};              // hour of medicine 1, 2, 3
int remM[3] = {0, 30, 0};               // minute of medicine 1, 2, 3
const unsigned long MISS_SECONDS = 30;  // time allowed to press Confirm
const unsigned long MSG_SECONDS = 4;    // how long DONE / MISSED messages stay

const int S_IDLE = 0, S_ALARM = 1, S_MISSED = 2, S_DONE = 3;

LiquidCrystal_I2C lcd(0x27, 16, 2);
RTC_DS1307 rtc;
DateTime cur;                           // latest time read from the RTC
int state = S_IDLE;
int activeNo = 0;                       // which medicine (0..2) is ringing
int lastDay[3] = {0, 0, 0};             // day-of-month each reminder last fired
bool dupShown[3] = {false, false, false};
int page = 0;                           // 0 = next reminder, 1..3 = schedule of M1..M3
int nextIdx = 0, nextDiff = 0;          // next reminder: index and minutes away
bool testMode = false, beepOn = false;
bool lastBtn[3] = {HIGH, HIGH, HIGH};
unsigned long btnTime[3] = {0, 0, 0};
unsigned long stateStart = 0, lastTick = 0;

// True once each time button i is pressed (with simple debounce)
bool pressed(int i) {
  bool v = digitalRead(BTN_PINS[i]);
  bool hit = (lastBtn[i] == HIGH && v == LOW && millis() - btnTime[i] > 50);
  if (hit) btnTime[i] = millis();
  lastBtn[i] = v;
  return hit;
}

// Print one padded line on the LCD (row 0 or 1)
void show(int row, const char *text) {
  char b[17];
  snprintf(b, 17, "%-16s", text);
  lcd.setCursor(0, row);
  lcd.print(b);
}

// Write an event to the Serial Monitor with a time stamp
void logEvent(const char *msg, int no) {
  char b[20];
  snprintf(b, sizeof(b), "[%02d:%02d:%02d] ", cur.hour(), cur.minute(), cur.second());
  Serial.print(b);
  Serial.print(msg);
  if (no > 0) {
    snprintf(b, sizeof(b), " (M%d %02d:%02d)", no, remH[no - 1], remM[no - 1]);
    Serial.print(b);
  }
  Serial.println();
}

// Blink red LED and beep buzzer together (non-blocking)
void beep() {
  bool on = (millis() / 250) % 2 == 0;
  if (on == beepOn) return;
  beepOn = on;
  digitalWrite(RED_LED, on);
  if (on) tone(BUZZER, 1000); else noTone(BUZZER);
}

void alarmOff() {
  beepOn = false;
  noTone(BUZZER);
  digitalWrite(RED_LED, LOW);
}

// Find the next reminder (ignores ones already done today)
void findNext() {
  int nowMin = cur.hour() * 60 + cur.minute();
  nextDiff = 9999;
  for (int i = 0; i < 3; i++) {
    int diff = remH[i] * 60 + remM[i] - nowMin;
    if (diff < 0 || lastDay[i] == cur.day()) diff += 1440;   // tomorrow
    if (diff < nextDiff) { nextDiff = diff; nextIdx = i; }
  }
}

void startAlarm(int i) {
  state = S_ALARM;
  activeNo = i;
  stateStart = millis();
  lastDay[i] = cur.day();               // remember: done for today
  logEvent("REMINDER DUE - buzzer + red LED ON", i + 1);
}

void acknowledge() {
  alarmOff();
  digitalWrite(GREEN_LED, HIGH);
  tone(BUZZER, 2000, 150);              // short happy beep
  state = S_DONE;
  stateStart = millis();
  logEvent("ACKNOWLEDGED - green LED ON", activeNo + 1);
}

// TEST MODE: move the RTC to 10 seconds before the next reminder
void jumpToNext() {
  findNext();
  DateTime target(cur.year(), cur.month(), cur.day(), remH[nextIdx], remM[nextIdx], 0);
  if (nextDiff >= 1440) target = target + TimeSpan(1, 0, 0, 0);
  target = target - TimeSpan(0, 0, 0, 10);
  if (target > cur) rtc.adjust(target);
  cur = rtc.now();
  logEvent("TEST: clock jumped to 10s before", nextIdx + 1);
}

// Start a reminder when the time matches (only once per day)
void checkSchedules() {
  for (int i = 0; i < 3; i++) {
    bool match = (cur.hour() == remH[i] && cur.minute() == remM[i]);
    if (!match) { dupShown[i] = false; continue; }
    if (lastDay[i] != cur.day()) { startAlarm(i); return; }
    if (!dupShown[i]) {
      dupShown[i] = true;
      logEvent("Duplicate blocked (already done today)", i + 1);
    }
  }
}

// Serial Monitor commands:  "N H M"  (N=1..3 sets medicine time, N=4 sets clock)
void readSerial() {
  if (!Serial.available()) return;
  char buf[20];
  int len = Serial.readBytesUntil('\n', buf, 19);
  buf[len] = 0;
  if (len == 0) return;
  int n = 0, h = 0, m = 0;
  if (sscanf(buf, "%d %d %d", &n, &h, &m) != 3 || n < 1 || n > 4 || h < 0 || h > 23 || m < 0 || m > 59) {
    Serial.println("Type: N H M  (N=1..3 medicine time, N=4 sets clock)");
    return;
  }
  if (n == 4) {
    rtc.adjust(DateTime(cur.year(), cur.month(), cur.day(), h, m, 0));
    cur = rtc.now();
    for (int i = 0; i < 3; i++) lastDay[i] = 0;   // new clock = fresh day
    logEvent("Clock set from Serial Monitor", 0);
  } else {
    remH[n - 1] = h;
    remM[n - 1] = m;
    lastDay[n - 1] = 0;
    logEvent("Schedule changed", n);
  }
}

// Runs every 200 ms: state changes and LCD drawing
void update() {
  char b[17], d[8];
  if (state == S_IDLE) checkSchedules();
  unsigned long el = (millis() - stateStart) / 1000;   // seconds in this state

  if (state == S_ALARM && el >= MISS_SECONDS) {         // nobody pressed Confirm
    alarmOff();
    digitalWrite(RED_LED, HIGH);
    tone(BUZZER, 300, 800);
    state = S_MISSED;
    stateStart = millis();
    el = 0;
    logEvent("MISSED REMINDER - not confirmed in time", activeNo + 1);
  }
  if ((state == S_MISSED || state == S_DONE) && el >= MSG_SECONDS) {
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, LOW);
    state = S_IDLE;
    findNext();
    logEvent("Next reminder is", nextIdx + 1);
  }

  if (state == S_ALARM) {
    snprintf(b, 17, "TAKE MEDICINE %d", activeNo + 1);
    show(0, b);
    snprintf(b, 17, "Due %02d:%02d  %lus", remH[activeNo], remM[activeNo], MISS_SECONDS - el);
    show(1, b);
  } else if (state == S_MISSED) {
    show(0, "MISSED REMINDER!");
    snprintf(b, 17, "Medicine %d %02d:%02d", activeNo + 1, remH[activeNo], remM[activeNo]);
    show(1, b);
  } else if (state == S_DONE) {
    show(0, "CONFIRMED!");
    snprintf(b, 17, "Medicine %d taken", activeNo + 1);
    show(1, b);
  } else {                                              // normal clock screen
    if (testMode) strcpy(d, "TEST");
    else snprintf(d, 8, "%02d/%02d", cur.day(), cur.month());
    snprintf(b, 17, "%02d:%02d:%02d %s", cur.hour(), cur.minute(), cur.second(), d);
    show(0, b);
    if (page == 0) {
      findNext();
      snprintf(b, 17, "Next M%d %02d:%02d%s", nextIdx + 1, remH[nextIdx], remM[nextIdx],
               nextDiff >= 1440 ? "+1d" : "");
    } else {
      snprintf(b, 17, "M%d %02d:%02d  %s", page, remH[page - 1], remM[page - 1],
               lastDay[page - 1] == cur.day() ? "done" : "wait");
    }
    show(1, b);
  }
}

void setup() {
  Serial.begin(9600);
  Serial.setTimeout(50);
  for (int i = 0; i < 3; i++) pinMode(BTN_PINS[i], INPUT_PULLUP);
  pinMode(BUZZER, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  lcd.init();
  lcd.backlight();
  if (!rtc.begin()) {
    show(0, "RTC NOT FOUND");
    Serial.println("ERROR: RTC not found - check wiring");
    while (1);
  }
  if (!rtc.isrunning()) rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  cur = rtc.now();
  show(0, "  MediTime v1.0");
  show(1, " Stay healthy!");
  tone(BUZZER, 1500, 150);
  Serial.println("=== MediTime started ===");
  for (int i = 1; i <= 3; i++) logEvent("Schedule loaded", i);
  delay(1500);
}

void loop() {
  readSerial();
  bool okBtn = pressed(0), nextBtn = pressed(1), modeBtn = pressed(2);
  if (okBtn && state == S_ALARM) acknowledge();
  if (modeBtn) {
    testMode = !testMode;
    logEvent(testMode ? "TEST MODE ON (Next = jump clock)" : "TEST MODE OFF", 0);
  }
  if (nextBtn) {
    if (testMode) { if (state == S_IDLE) jumpToNext(); }
    else { page = (page + 1) % 4; logEvent("Display page changed", 0); }
  }
  if (state == S_ALARM) beep();
  if (millis() - lastTick >= 200) {
    lastTick = millis();
    cur = rtc.now();
    update();
  }
}